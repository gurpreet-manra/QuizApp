 <aside>
          <div id="sidebar"  class="nav-collapse ">
            
              <ul class="sidebar-menu" id="nav-accordion">
              
              	 
              	  	
                  <li class="mt">
                      <a  href="index.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="users.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Users</span>
                      </a>
                     
                  </li>

                  <li class="sub-menu">
                      <a href="addQuestion.php" >
                          <i class="fa fa-cogs"></i>
                          <span>Add Question</span>
                      </a>
                     
                  </li>
                  <li class="sub-menu">
                      <a href="questions.php" >
                          <i class="fa fa-book"></i>
                          <span>Questions</span>
                      </a>
                      
                  </li>
		   <li class="sub-menu">
                      <a href="addtest.php" >
                          <i class="fa fa-book"></i>
                          <span>Add Test</span>
                      </a>
                      
                  </li>
		   </li>
		   <li class="sub-menu">
                      <a href="changetest.php" >
                          <i class="fa fa-book"></i>
                          <span>Change Tests</span>
                      </a>
                      
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-tasks"></i>
                          <span>Forms</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="form_component.php">Form Components</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-th"></i>
                          <span>Data Tables</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="basic_table.php">Basic Table</a></li>
                          <li><a  href="responsive_table.php">Responsive Table</a></li>
                      </ul>
                  </li>
                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class=" fa fa-bar-chart-o"></i>
                          <span>Charts</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="morris.html">Morris</a></li>
                          <li><a  href="chartjs.html">Chartjs</a></li>
                      </ul>
                  </li>

              </ul>
             
          </div>
      </aside>