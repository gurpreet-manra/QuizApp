  <header class="header black-bg">
             
          
            <a href="index.html" class="logo"><b>Admin</b></a>
            
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>