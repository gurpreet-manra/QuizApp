<?php
ob_start();
session_start();
if($_SESSION['admin_id'] == ''){
	
 header('Location: login.php');
} else{
	require_once('../database.php');
	$input = 'pass';
	$input1 = 'fail';
	$query = 'select * from test where status = :input';
$statement = $db->prepare($query);
$statement->bindValue(':input', $input);
$statement->execute();
$product = $statement->fetchAll();
$number = count($product);


$query1 = 'select * from test where status = :input';
$statement1 = $db->prepare($query1);
$statement1->bindValue(':input', $input1);
$statement1->execute();
$product1 = $statement1->fetchAll();
$number1 = count($product1);

$query2 = 'select * from test';
$statement2 = $db->prepare($query2);
$statement2->execute();
$product2 = $statement2->fetchAll();
$number2 = count($product2);
$div = $number2*10;
$total = 0;
foreach($product2 as $no){
	$total += $no['score'];
}
$avg = $total/$div;
}

include('head.php');
?>
  <body>

  <section id="container" >
     
    <?php
include('include/topbar.php');
include('include/sidebar.php');
?>
           <section id="main-content">
          <section class="wrapper">

              <div class="row">
                  <div class="col-lg-9 main-chart">
                  
                    <div class="row mt">
                    
                      	<div class="col-md-4 mb">
						
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Passed Users</h5>
								</div>
								
							
								<div class="row">
									<div >
										<br>
										<br>
										<br>
											
										<h2><?php echo $number; ?> </h2>
									</div>
									
								</div>
							</div>
						</div>
                      	

                  	<div class="col-md-4 mb">
							
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Failed Users</h5>
								</div>
								
							
								<div class="row">
									<div >
										<br>
										<br>
										<br>
											
										<h2><?php echo $number1; ?></h2>
									</div>
									
								</div>
							</div>
						</div>
                      	
					    	<div class="col-md-4 mb">
					
							<div class="white-panel pn">
								<div class="white-header">
									<h5>Avarage Score</h5>
								</div>
								
							
								<div class="row">
									<div >
										<br>
										<br>
										<br>
											
										<h2><?php echo $avg; ?></h2>
									</div>
									
								</div>
							</div>
						</div>
                      	

                    </div>
                   
        </div>
                  
                  
     
              </div>
          </section>
      </section>
    
    
  </section>

    
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/jquery-1.8.3.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="assets/js/jquery.sparkline.js"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>
    
    <script type="text/javascript" src="assets/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="assets/js/gritter-conf.js"></script>

    <!--script for this page-->
    <script src="assets/js/sparkline-chart.js"></script>    
	<script src="assets/js/zabuto_calendar.js"></script>	

	
	<script type="application/javascript">
        $(document).ready(function () {
            $("#date-popover").popover({html: true, trigger: "manual"});
            $("#date-popover").hide();
            $("#date-popover").click(function (e) {
                $(this).hide();
            });
        
            $("#my-calendar").zabuto_calendar({
                action: function () {
                    return myDateFunction(this.id, false);
                },
                action_nav: function () {
                    return myNavFunction(this.id);
                },
                ajax: {
                    url: "show_data.php?action=1",
                    modal: true
                },
                legend: [
                    {type: "text", label: "Special event", badge: "00"},
                    {type: "block", label: "Regular event", }
                ]
            });
        });
        
        
        function myNavFunction(id) {
            $("#date-popover").hide();
            var nav = $("#" + id).data("navigation");
            var to = $("#" + id).data("to");
            console.log('nav ' + nav + ' to: ' + to.month + '/' + to.year);
        }
    </script>
  

  </body>
</html>
