<?php
ob_start();
session_start();
if($_SESSION['admin_id'] == ''){
	
 header('Location: login.php');
} else{
session_destroy();
header('location: login.php');
 exit(); 
}
?>